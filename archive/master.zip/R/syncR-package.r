#' syncR.
#'
#' @name syncR
#' @docType package
NULL
